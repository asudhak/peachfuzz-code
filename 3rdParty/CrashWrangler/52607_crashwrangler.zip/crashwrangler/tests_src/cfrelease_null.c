#include <CoreFoundation/CoreFoundation.h>

int main() {
    CFRelease(0);
    
}