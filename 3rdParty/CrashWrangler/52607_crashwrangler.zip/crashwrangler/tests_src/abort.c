#include <stdlib.h>
int main() {
	abort();
}