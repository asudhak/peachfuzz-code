
void foo() {
    foo();
}

int main() {
    foo();
}